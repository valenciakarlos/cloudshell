from steps import go

go(True)
